"""
PTMAE: Pure Python Transactional Micro-Banking & Audit Engine
============================================================
A fully compliant, zero-dependency, pure Python banking and audit engine.
Authored with pedagogical commentary and industrial-grade rigor.

Allowed imports: ONLY 'random' and 'datetime'.
Banned: csv, json, re, math, os, sys, sqlite3, pandas, numpy, etc.
"""

import datetime
import random


# ============================================================================
# [SECTION A — INTERACTIVE ENGINE + GUARDS]
# ============================================================================

# Mentor Note: Pure arithmetic compounding avoids floating-point divergence by
# modeling interest accumulation over discrete cycle intervals using elementary operators.
def calculate_compound_interest_and_penalty(
    principal: float,
    annual_rate: float,
    periods_per_year: int,
    years: int,
    late_penalty_days: int = 0,
    daily_penalty_rate: float = 0.0
) -> dict:
    """
    Computes compound interest and late penalties using ONLY +, -, *, /, //, %, **.
    
    The math module is strictly forbidden. Compounding is modeled iteratively per
    compounding period, and penalty accumulation is simulated across delinquent days.
    
    Parameters:
        principal (float): Base monetary investment or loan amount.
        annual_rate (float): Nominal annual interest rate (e.g., 0.05 for 5%).
        periods_per_year (int): Frequency of compounding per year (e.g., 12 for monthly).
        years (int): Total investment duration in years.
        late_penalty_days (int): Number of days elapsed past payment due date.
        daily_penalty_rate (float): Daily penalty percentage applied to delinquent balance.
        
    Returns:
        dict: Breakdown containing compounded_balance, penalty_charge, total_due,
              and total_interest_earned.
    """
    if principal < 0 or annual_rate < 0 or periods_per_year <= 0 or years < 0:
        raise ValueError("Financial parameters must be non-negative, and periods must be positive.")

    # Periodic interest rate calculated via pure division
    periodic_rate = annual_rate / periods_per_year
    total_periods = periods_per_year * years

    # Iterative compounding loop simulating discrete time steps
    compounded_balance = principal
    period_idx = 0
    while period_idx < total_periods:
        interest_increment = compounded_balance * periodic_rate
        compounded_balance = compounded_balance + interest_increment
        period_idx += 1

    # Late fee calculation executed day-by-day via repeated addition
    penalty_charge = 0.0
    day_idx = 0
    while day_idx < late_penalty_days:
        daily_fee = compounded_balance * daily_penalty_rate
        penalty_charge = penalty_charge + daily_fee
        day_idx += 1

    total_due = compounded_balance + penalty_charge
    total_interest = compounded_balance - principal

    return {
        "principal": principal,
        "compounded_balance": compounded_balance,
        "penalty_charge": penalty_charge,
        "total_due": total_due,
        "total_interest_earned": total_interest
    }


# Mentor Note: Short-circuiting with 'or' stops pipeline evaluation immediately upon
# reaching an unsafe invariant, preventing downstream corruption without exception overhead.
def guard_trajectory(
    events: list,
    safety_threshold: float = 1000.0,
    termination_flag: str = "HALT"
) -> dict:
    """
    Walks a transaction sequence and short-circuits instantly when:
    (a) Running balance drops strictly below safety_threshold, OR
    (b) An event payload contains the specified termination_flag.
    
    Parameters:
        events (list): Sequence of transaction records (dicts with 'amount', 'flag', 'tx_id').
        safety_threshold (float): Minimum permissible balance before instant termination.
        termination_flag (str): Signal string that demands immediate halt.
        
    Returns:
        dict: Trajectory status, final balance, processed count, and halt reason.
    """
    current_balance = 0.0
    processed_steps = 0
    halt_reason = "COMPLETED_NORMALLY"
    halted_early = False

    for event in events:
        amount = event.get("amount", 0.0)
        flag = event.get("flag", "")
        projected_balance = current_balance + amount

        # Instant short-circuit evaluation combining threshold violation and halt flag
        if (projected_balance < safety_threshold) or (flag == termination_flag):
            halted_early = True
            if projected_balance < safety_threshold and flag == termination_flag:
                halt_reason = "CRITICAL_DUAL_VIOLATION: BALANCE_BELOW_THRESHOLD_AND_HALT_FLAG"
            elif projected_balance < safety_threshold:
                halt_reason = f"SAFETY_BREACH: BALANCE {projected_balance:.2f} < {safety_threshold:.2f}"
            else:
                halt_reason = f"FLAG_TERMINATION: ENCOUNTERED '{termination_flag}'"
            break

        current_balance = projected_balance
        processed_steps += 1

    return {
        "halted_early": halted_early,
        "halt_reason": halt_reason,
        "final_balance": current_balance,
        "processed_steps": processed_steps,
        "total_events": len(events)
    }


# Mentor Note: Nested while loops isolate top-level system lifetime from session-level command
# dispatch, ensuring transient command syntax errors never crash the host process.
def run_interactive_engine(command_stream: list = None) -> None:
    """
    Executes a crash-proof text CLI using nested while loops with a prompt and help system.
    
    Invalid commands display friendly diagnostics and the prompt continues seamlessly.
    Only the explicit command 'exit' terminates execution.
    
    Parameters:
        command_stream (list, optional): Pre-programmed command list for automated testing.
                                        If None, consumes live input via input().
    """
    stream_idx = 0
    engine_online = True

    print("\n=======================================================")
    print("  PTMAE MICRO-BANKING & AUDIT ENGINE [CLI ONLINE]     ")
    print("  Type 'help' for command listing or 'exit' to quit.   ")
    print("=======================================================")

    while engine_online:
        session_active = True

        while session_active:
            # Command acquisition from either stream or interactive terminal
            raw_input_line = ""
            if command_stream is not None:
                if stream_idx < len(command_stream):
                    raw_input_line = command_stream[stream_idx]
                    stream_idx += 1
                    print(f"PTMAE-cli> {raw_input_line}")
                else:
                    raw_input_line = "exit"
            else:
                try:
                    raw_input_line = input("PTMAE-cli> ")
                except (EOFError, KeyboardInterrupt):
                    print("\n[CLI] Session terminated by user signal.")
                    raw_input_line = "exit"

            # Clean leading/trailing whitespace manually
            cleaned_command = raw_input_line.strip()
            if not cleaned_command:
                continue

            # Command extraction without str.split()
            cmd_tokens = []
            cur_token = []
            for ch in cleaned_command:
                if ch == " " or ch == "\t":
                    if cur_token:
                        cmd_tokens.append("".join(cur_token))
                        cur_token = []
                else:
                    cur_token.append(ch)
            if cur_token:
                cmd_tokens.append("".join(cur_token))

            main_cmd = cmd_tokens[0].lower() if cmd_tokens else ""

            if main_cmd == "exit":
                print("[CLI] Shutting down transactional engine session. Goodbye.")
                session_active = False
                engine_online = False
                break

            elif main_cmd == "help":
                print("\n--- AVAILABLE COMMANDS ---")
                print("  help                                 : Display this manual")
                print("  status                               : Print engine operational health")
                print("  calc <p> <rate> <freq> <yrs> [d] [r] : Run compound/penalty calculator")
                print("  guard <start_bal> <min_bal> <a,b,c>  : Run trajectory short-circuit check")
                print("  exit                                 : Safely terminate the engine\n")

            elif main_cmd == "status":
                print(f"[STATUS] Engine active. System timestamp: {datetime.datetime.now().isoformat()}")

            elif main_cmd == "calc":
                if len(cmd_tokens) < 5:
                    print("[ERROR] Usage: calc <principal> <rate> <periods_per_year> <years> [penalty_days] [penalty_rate]")
                    continue
                try:
                    p = float(cmd_tokens[1])
                    r = float(cmd_tokens[2])
                    freq = int(cmd_tokens[3])
                    yrs = int(cmd_tokens[4])
                    p_days = int(cmd_tokens[5]) if len(cmd_tokens) > 5 else 0
                    p_rate = float(cmd_tokens[6]) if len(cmd_tokens) > 6 else 0.0
                    res = calculate_compound_interest_and_penalty(p, r, freq, yrs, p_days, p_rate)
                    print(f"[CALC RESULT] Compounded: {res['compounded_balance']:.2f} | Penalty: {res['penalty_charge']:.2f} | Total: {res['total_due']:.2f}")
                except ValueError as ve:
                    print(f"[ERROR] Invalid numerical argument in calc command: {ve}")

            elif main_cmd == "guard":
                if len(cmd_tokens) < 4:
                    print("[ERROR] Usage: guard <initial_balance> <threshold> <amount1,amount2,...>")
                    continue
                try:
                    init_bal = float(cmd_tokens[1])
                    thresh = float(cmd_tokens[2])
                    raw_amts = cmd_tokens[3]
                    amt_tokens = parse_raw_log_line(raw_amts)
                    events = [{"amount": init_bal, "flag": None, "tx_id": "INIT"}]
                    for idx, a_str in enumerate(amt_tokens):
                        if a_str.strip():
                            events.append({"amount": float(a_str), "flag": None, "tx_id": f"TX_{idx}"})
                    res = guard_trajectory(events, safety_threshold=thresh)
                    print(f"[GUARD RESULT] Halted Early: {res['halted_early']} | Final Bal: {res['final_balance']:.2f} | Reason: {res['halt_reason']}")
                except ValueError as ve:
                    print(f"[ERROR] Malformed trajectory arguments: {ve}")

            else:
                print(f"[UNRECOGNIZED COMMAND] '{main_cmd}' is unknown. Type 'help' for instructions.")


# ============================================================================
# [SECTION B — MANUAL PARSER + FUNCTION MECHANICS]
# ============================================================================

# Mentor Note: Implementing a finite state automaton index-by-index guarantees deterministic
# RFC-4180 parsing while completely eliminating forbidden convenience functions like split/replace.
def parse_raw_log_line(line: str, delimiter: str = ",", quote_char: str = '"') -> list:
    """
    Parses a raw log or CSV record index-by-index using manual iteration and state flags.
    
    STRICT COMPLIANCE:
    - Does NOT use str.split() or str.replace().
    - Treats delimiters inside quoted strings as literal data.
    - Converts escaped quotes ("") into a single literal quote.
    - Preserves empty fields (e.g., 'a,,b' -> ['a', '', 'b']).
    - Tolerates trailing delimiters (e.g., 'a,b,' -> ['a', 'b', '']).
    - Handles line endings (\r, \n) without library routines.
    
    Parameters:
        line (str): The raw input line.
        delimiter (str): Field separator (default comma).
        quote_char (str): Escaping quote character (default double quote).
        
    Returns:
        list of str: Cleaned string tokens.
    """
    # Strip terminal carriage returns or newlines manually
    end_bound = len(line)
    while end_bound > 0 and (line[end_bound - 1] == "\n" or line[end_bound - 1] == "\r"):
        end_bound -= 1
    sanitized_line = line[:end_bound]

    tokens = []
    current_chars = []
    in_quotes = False
    idx = 0
    n = len(sanitized_line)

    while idx < n:
        char = sanitized_line[idx]

        if in_quotes:
            if char == quote_char:
                # Check for escaped quote sequence: "" -> "
                if (idx + 1 < n) and (sanitized_line[idx + 1] == quote_char):
                    current_chars.append(quote_char)
                    idx += 2
                    continue
                else:
                    # Closing quote
                    in_quotes = False
                    idx += 1
                    continue
            else:
                current_chars.append(char)
                idx += 1
        else:
            if char == quote_char:
                in_quotes = True
                idx += 1
            elif char == delimiter:
                tokens.append("".join(current_chars))
                current_chars = []
                idx += 1
            else:
                current_chars.append(char)
                idx += 1

    # Append trailing accumulated token
    tokens.append("".join(current_chars))
    return tokens


# Mentor Note: Closures capture variables from their enclosing scope; using 'nonlocal'
# allows rebinding of outer variables without leaking state into the global namespace.
def make_audit_filter(threshold: float):
    """
    Generates an isolated audit filter closure retaining persistent execution state.
    
    Maintains an audit counter in the enclosing scope using 'nonlocal'.
    Each returned filter instance retains independent, persistent counters.
    
    Parameters:
        threshold (float): Transaction amount boundary that flags an audit event.
        
    Returns:
        function: An inner function (amount, note) -> dict.
    """
    call_count = 0
    breach_count = 0

    def audit_filter(amount: float, note: str = "") -> dict:
        nonlocal call_count, breach_count
        call_count += 1
        is_breach = amount >= threshold
        if is_breach:
            breach_count += 1

        return {
            "amount": amount,
            "threshold": threshold,
            "note": note,
            "is_breach": is_breach,
            "call_count": call_count,
            "breach_count": breach_count
        }

    return audit_filter


# Mentor Note: Python closures bind variables by reference at execution time (late binding).
# Default argument binding (k=k) forces immediate evaluation at definition time.
def build_position_filters(k_count: int) -> list:
    """
    Builds k position-based token filters as a list of lambdas within a loop.
    
    Each lambda captures its unique position k via default argument binding (k=k),
    immunizing against late-binding bugs without invoking the global keyword.
    
    Parameters:
        k_count (int): Number of position filters to generate.
        
    Returns:
        list of callables: List of lambdas filtering records at index k.
    """
    filters = []
    for k in range(k_count):
        # Default argument binding: k=k freezes current loop index
        filters.append(lambda record, pos=k: len(record) > pos and record[pos] != "")
    return filters


# ============================================================================
# [SECTION C — REVERSE INDEX + SAME-OBJECT CLEANUP]
# ============================================================================

# Mentor Note: Dict comprehensions express relational inversions declaratively;
# combining set deduplication with sorting yields canonical multi-key indices in one pass.
def build_reverse_service_index(raw_db: dict) -> dict:
    """
    Builds a reverse service index in a SINGLE dictionary comprehension.
    
    Transforms branch-centric account data:
      raw_db = {
        "BRANCH_01": [("Acc1@1", {"DEPOSIT", "UPI"}), ("Acc1@2", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
      }
    Into service-centric sorted mappings:
      "UPI" -> [("Acc1@1", "BRANCH_01"), ("Acc1@2", "BRANCH_01"), ("Acc101", "BRANCH_02")]
      
    Parameters:
        raw_db (dict): Mapping of Branch_ID to list of (Account_ID, Service_Set) tuples.
        
    Returns:
        dict: Mapping of Service_Tag to alphabetically sorted unique (Account_ID, Branch_ID) tuples.
    """
    # Single dictionary comprehension with nested generator expressions
    reverse_index = {
        service_tag: sorted(list({
            (acc_id, branch_id)
            for branch_id, account_list in raw_db.items()
            for acc_id, services in account_list
            if service_tag in services
        }))
        for service_tag in sorted({
            tag
            for account_list in raw_db.values()
            for _, services in account_list
            for tag in services
        })
    }
    return reverse_index


# Mentor Note: Mutating in-place requires direct index assignment and backward deletion passes,
# preserving pointer identity id(data_list) without creating auxiliary set/list buffers.
def scrub_queue(data_list: list) -> None:
    """
    Scrubs and normalizes a heterogeneous queue IN PLACE, keeping id(data_list) constant.
    
    Mutation Steps:
    1. Converts all top-level tuples to lists.
    2. Evicts all even transaction IDs from sets using set difference.
    3. Sorts each inner list in descending order (via manual in-place bubble sort).
    4. Drops duplicate primitive values (int, float, str, bool) by scanning and
       deleting by index without allocating any helper collection.
       
    Parameters:
        data_list (list): The list object to mutate in place.
    """
    # Step 1: In-place conversion of tuples to lists
    idx = 0
    while idx < len(data_list):
        if type(data_list[idx]) is tuple:
            data_list[idx] = list(data_list[idx])
        idx += 1

    # Step 2: Remove even transaction IDs from sets via set difference
    idx = 0
    while idx < len(data_list):
        if type(data_list[idx]) is set:
            # Build set of even integers to evict
            even_eviction_set = {
                val for val in data_list[idx]
                if type(val) is int and val % 2 == 0
            }
            data_list[idx] = data_list[idx] - even_eviction_set
        idx += 1

    # Step 3: Sort each inner list in descending order using manual bubble sort
    def _is_less(a, b):
        try:
            return a < b
        except TypeError:
            return (type(a).__name__, str(a)) < (type(b).__name__, str(b))

    idx = 0
    while idx < len(data_list):
        if type(data_list[idx]) is list:
            target_sublist = data_list[idx]
            sub_len = len(target_sublist)
            i = 0
            while i < sub_len:
                j = 0
                while j < sub_len - i - 1:
                    # Descending sort: swap if left item is smaller than right item
                    if _is_less(target_sublist[j], target_sublist[j + 1]):
                        temp_val = target_sublist[j]
                        target_sublist[j] = target_sublist[j + 1]
                        target_sublist[j + 1] = temp_val
                    j += 1
                i += 1
        idx += 1

    # Step 4: Drop duplicate primitives by manual backward index scanning (NO helper collections)
    i = 0
    while i < len(data_list):
        curr_item = data_list[i]
        # Only inspect primitive types
        if type(curr_item) in (int, float, str, bool):
            # Scan backward from tail towards i + 1 to delete duplicate instances safely
            j = len(data_list) - 1
            while j > i:
                comparison_item = data_list[j]
                if type(comparison_item) is type(curr_item) and comparison_item == curr_item:
                    del data_list[j]
                j -= 1
        i += 1


# ============================================================================
# [SECTION D — R+ FILE SURGERY + DUAL LOGGING]
# ============================================================================

# Mentor Note: Custom exception hierarchies provide structured error domain boundaries,
# enabling precise catch targets while retaining inheritance from a base engine fault.
class BaseSystemError(Exception):
    """Root exception for all PTMAE micro-banking errors."""
    pass


class CorruptedRecordError(BaseSystemError):
    """Raised when an accounts.db record violates schema, format, or type rules."""
    pass


class OutOfBoundsError(BaseSystemError):
    """Raised when an operation breaches authorized overdraft or credit boundaries."""
    pass


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot satisfy minimum balance or settlement amounts."""
    pass


# Mentor Note: In-place chunked byte shifting in r+ mode achieves constant-memory updates
# by reading and moving tail blocks without ever reading the whole file into RAM.
def update_account_record_inplace(
    db_path: str,
    target_acc_id: str,
    new_account_type: str,
    new_balance: float,
    chunk_size: int = 64
) -> bool:
    """
    Updates a specific record in accounts.db IN PLACE using r+ mode and chunked shifting.
    
    STRICT COMPLIANCE:
    - Never reads entire file into memory.
    - Never uses 'w' mode.
    - Uses f.tell() and f.seek() for exact byte repositioning.
    - Chunked seek/read/write passes shift the file tail when payload length changes.
    - Finishes with f.truncate() on contraction to ensure neighbouring lines stay byte-identical.
    
    Parameters:
        db_path (str): Path to accounts.db.
        target_acc_id (str): Account identifier to locate and update.
        new_account_type (str): Updated account classification (SAVINGS, CURRENT, CREDIT).
        new_balance (float): Updated numerical balance.
        chunk_size (int): Size of buffer used for chunked shifting passes.
        
    Returns:
        bool: True if record was located and updated; False otherwise.
    """
    valid_types = {"SAVINGS", "CURRENT", "CREDIT"}
    if new_account_type not in valid_types:
        raise CorruptedRecordError(f"Invalid account type '{new_account_type}'.")
    if new_balance < 0:
        raise CorruptedRecordError(f"Negative balance {new_balance} not permitted.")

    # Open with newline='' to ensure byte-precise pointer positioning across platforms
    with open(db_path, "r+", encoding="utf-8", newline="") as f:
        record_found = False
        record_start = 0
        record_end = 0

        while True:
            line_start_pos = f.tell()
            line = f.readline()
            if not line:
                break

            parsed_tokens = parse_raw_log_line(line)
            if parsed_tokens and parsed_tokens[0] == target_acc_id:
                record_found = True
                record_start = line_start_pos
                record_end = f.tell()
                break

        if not record_found:
            return False

        old_length = record_end - record_start
        new_payload = f"{target_acc_id},{new_account_type},{new_balance:.2f}\n"
        new_length = len(new_payload)
        diff = new_length - old_length

        if diff == 0:
            # Case 1: Exact length match -> Overwrite directly in place
            f.seek(record_start)
            f.write(new_payload)
            f.flush()

        elif diff < 0:
            # Case 2: Contraction (new record is shorter)
            # Write new record, then shift downstream tail LEFT by abs(diff) bytes
            f.seek(record_start)
            f.write(new_payload)

            write_ptr = record_start + new_length
            read_ptr = record_end

            f.seek(0, 2)
            file_end = f.tell()

            while read_ptr < file_end:
                bytes_to_read = chunk_size
                if file_end - read_ptr < bytes_to_read:
                    bytes_to_read = file_end - read_ptr

                f.seek(read_ptr)
                chunk = f.read(bytes_to_read)
                if not chunk:
                    break

                actual_bytes = len(chunk)
                f.seek(write_ptr)
                f.write(chunk)

                read_ptr += actual_bytes
                write_ptr += actual_bytes

            # Truncate surplus file tail at new terminal position
            f.seek(write_ptr)
            f.truncate(write_ptr)
            f.flush()

        else:
            # Case 3: Expansion (new record is longer)
            # Shift downstream tail RIGHT by diff bytes, reading chunks from EOF backward
            f.seek(0, 2)
            file_end = f.tell()
            cur_read_end = file_end

            while cur_read_end > record_end:
                bytes_to_read = chunk_size
                if cur_read_end - record_end < bytes_to_read:
                    bytes_to_read = cur_read_end - record_end

                cur_read_start = cur_read_end - bytes_to_read
                f.seek(cur_read_start)
                chunk = f.read(bytes_to_read)

                cur_write_start = cur_read_start + diff
                f.seek(cur_write_start)
                f.write(chunk)

                cur_read_end = cur_read_start

            # Write newly expanded payload into the created gap
            f.seek(record_start)
            f.write(new_payload)
            f.flush()

        return True


# Mentor Note: The try-except-else-finally construct guarantees comprehensive audit
# tracking: 'else' records valid state, 'except' quarantines faults, and 'finally' seals metrics.
def audit_and_execute_file_batch(
    db_path: str,
    ledger_path: str,
    corrupted_path: str,
    batch_updates: list
) -> tuple:
    """
    Executes a batch of file updates with strict dual logging and exception isolation.
    
    Structure per record: try-except-else-finally.
    - Accepted updates -> append timestamped record to ledger.txt.
    - Rejected updates -> append error and line coordinates to corrupted.log.
    - Finally block prints processed and rejected counts on every invocation.
    
    Parameters:
        db_path (str): Database file path.
        ledger_path (str): Success audit log path.
        corrupted_path (str): Rejection error log path.
        batch_updates (list): List of update tuples: (account_id, new_type, new_balance).
        
    Returns:
        tuple: (processed_count, rejected_count)
    """
    processed_count = 0
    rejected_count = 0

    try:
        # Pre-scan database file to establish line index mapping
        line_map = {}
        with open(db_path, "r", encoding="utf-8", newline="") as f:
            line_num = 1
            for raw_line in f:
                tokens = parse_raw_log_line(raw_line)
                if tokens and tokens[0]:
                    line_map[tokens[0]] = (line_num, raw_line.strip())
                line_num += 1

        for update in batch_updates:
            acc_id = update[0] if len(update) > 0 else "UNKNOWN"
            new_type = update[1] if len(update) > 1 else ""
            new_bal = update[2] if len(update) > 2 else None

            target_line_num = line_map.get(acc_id, (0, ""))[0]
            raw_entry = line_map.get(acc_id, (0, "N/A"))[1]

            try:
                # Validation checks that can raise CorruptedRecordError
                if acc_id not in line_map:
                    raise CorruptedRecordError(f"Account ID '{acc_id}' not found in database records.")

                if new_type not in {"SAVINGS", "CURRENT", "CREDIT"}:
                    raise CorruptedRecordError(f"Unknown account type '{new_type}'.")

                if not isinstance(new_bal, (int, float)):
                    raise CorruptedRecordError(f"Balance '{new_bal}' is not numeric.")

                if new_bal < 0:
                    raise CorruptedRecordError(f"Negative balance {new_bal} violates schema.")

                # Execute in-place surgery
                success = update_account_record_inplace(db_path, acc_id, new_type, float(new_bal))
                if not success:
                    raise CorruptedRecordError(f"Failed to perform in-place update for '{acc_id}'.")

            except (CorruptedRecordError, BaseSystemError, Exception) as exc:
                rejected_count += 1
                timestamp = datetime.datetime.now().isoformat()
                log_entry = (
                    f"[{timestamp}] REJECTED | Line {target_line_num} | Record: '{raw_entry}' | "
                    f"Error: {exc.__class__.__name__} - {str(exc)}\n"
                )
                with open(corrupted_path, "a", encoding="utf-8") as f_err:
                    f_err.write(log_entry)

            else:
                processed_count += 1
                timestamp = datetime.datetime.now().isoformat()
                log_entry = (
                    f"[{timestamp}] SUCCESS | Line {target_line_num} | Account: {acc_id} | "
                    f"Type: {new_type} | Balance: {new_bal:.2f}\n"
                )
                with open(ledger_path, "a", encoding="utf-8") as f_ledger:
                    f_ledger.write(log_entry)

    finally:
        # Invariant summary printed on every run, guaranteed even during critical aborts
        print(f"\n[FILE AUDIT METRICS] Successfully Processed: {processed_count} | Total Rejected: {rejected_count}")

    return processed_count, rejected_count


# ============================================================================
# [SECTION E — ACCOUNTS HIERARCHY + SAFE BATCH SETTLEMENT]
# ============================================================================

# Mentor Note: Encapsulation shields state from unauthorized mutations; double-underscore
# prefixes trigger compiler name mangling, restricting access strictly to verified getters/setters.
class Account:
    """
    Base financial account implementing strict encapsulation and class lifecycle metrics.
    
    Attributes:
        total_accounts (int): Class attribute tracking total Account instances created.
        _account_id (str): Protected account identifier.
        __balance (float): Private balance accessible solely through validated properties.
    """
    total_accounts = 0

    def __init__(self, account_id: str, initial_balance: float):
        """
        Initializes base account attributes and increments global instance counter.
        """
        Account.total_accounts += 1
        self._account_id = str(account_id)

        if not isinstance(initial_balance, (int, float)):
            raise TypeError("Initial balance must be a numeric value.")
        if initial_balance < 0:
            raise ValueError("Initial balance cannot be negative.")

        self.__balance = float(initial_balance)

    @property
    def account_id(self) -> str:
        """Returns the protected account identifier."""
        return self._account_id

    @property
    def balance(self) -> float:
        """Returns the current private balance."""
        return self.__balance

    @balance.setter
    def balance(self, new_balance: float) -> None:
        """
        Validated setter for account balance.
        
        Raises:
            TypeError: If new_balance is not numeric.
        """
        if not isinstance(new_balance, (int, float)):
            raise TypeError("Account balance must be a numeric value.")
        self.__balance = float(new_balance)

    def process_settlement(self, amount: float) -> None:
        """
        Processes a generic balance settlement deduction.
        
        Raises:
            ValueError: If amount is non-positive.
            InsufficientBalanceError: If deduction exceeds balance.
        """
        if not isinstance(amount, (int, float)) or amount <= 0:
            raise ValueError("Settlement amount must be a positive numeric value.")
        if self.__balance - amount < 0:
            raise InsufficientBalanceError(f"Account {self._account_id} balance insufficient for settlement.")
        self.__balance = self.__balance - amount


# Mentor Note: Subclass constructors must delegate initialization upstream via super()
# to preserve dynamic method resolution order (MRO) and class hierarchy extensibility.
class SavingsAccount(Account):
    """
    Savings account enforcing a mandatory minimum liquidity floor of 1000.00 currency units.
    """
    def __init__(self, account_id: str, initial_balance: float):
        super().__init__(account_id, initial_balance)

    def process_settlement(self, amount: float) -> None:
        """
        Settles payment against savings reserves.
        
        Raises:
            InsufficientBalanceError: If remaining balance drops below the 1000.00 floor.
        """
        if not isinstance(amount, (int, float)) or amount <= 0:
            raise ValueError("Settlement amount must be positive.")

        remaining = self.balance - amount
        if remaining < 1000.0:
            raise InsufficientBalanceError(
                f"SavingsAccount [{self.account_id}]: Post-settlement balance {remaining:.2f} "
                f"breaches mandatory minimum liquidity floor of 1000.00."
            )
        self.balance = remaining


# Mentor Note: Private attributes in subclasses are independently mangled with their own class prefix,
# ensuring overdraft boundaries do not collide with or expose base class attributes.
class CurrentAccount(Account):
    """
    Commercial current account supporting authorized credit overdraft allowances.
    """
    def __init__(self, account_id: str, initial_balance: float, overdraft_limit: float = 5000.0):
        super().__init__(account_id, initial_balance)
        if not isinstance(overdraft_limit, (int, float)) or overdraft_limit < 0:
            raise ValueError("Overdraft limit must be a non-negative number.")
        self.__overdraft_limit = float(overdraft_limit)

    @property
    def overdraft_limit(self) -> float:
        """Returns the authorized private overdraft limit."""
        return self.__overdraft_limit

    @overdraft_limit.setter
    def overdraft_limit(self, limit: float) -> None:
        """Validated setter for authorized overdraft limit."""
        if not isinstance(limit, (int, float)) or limit < 0:
            raise ValueError("Overdraft limit must be non-negative.")
        self.__overdraft_limit = float(limit)

    def process_settlement(self, amount: float) -> None:
        """
        Settles commercial obligations against liquid balance and authorized overdraft facility.
        
        Raises:
            OutOfBoundsError: If settlement demand exceeds combined balance and overdraft facility.
        """
        if not isinstance(amount, (int, float)) or amount <= 0:
            raise ValueError("Settlement amount must be positive.")

        effective_balance = self.balance - amount
        if effective_balance < (-self.__overdraft_limit):
            raise OutOfBoundsError(
                f"CurrentAccount [{self.account_id}]: Required settlement {amount:.2f} exceeds "
                f"balance {self.balance:.2f} and overdraft limit {self.__overdraft_limit:.2f}."
            )
        self.balance = effective_balance


# Mentor Note: Credit billing structures apply percentage surcharges directly to nominal charges,
# deducting total obligations from authorized credit facilities.
class CreditAccount(Account):
    """
    Revolving credit account applying a mandatory 2.5% surcharge on all settlements.
    """
    def __init__(self, account_id: str, credit_limit: float = 10000.0, balance: float = 0.0):
        super().__init__(account_id, balance)
        if not isinstance(credit_limit, (int, float)) or credit_limit <= 0:
            raise ValueError("Credit limit must be a positive number.")
        self.__credit_limit = float(credit_limit)

    @property
    def credit_limit(self) -> float:
        """Returns the authorized revolving credit line limit."""
        return self.__credit_limit

    def process_settlement(self, amount: float) -> None:
        """
        Applies a 2.5% surcharge to settlement amount and deducts total from credit limit.
        
        Raises:
            OutOfBoundsError: If total obligation exceeds remaining credit limit.
        """
        if not isinstance(amount, (int, float)) or amount <= 0:
            raise ValueError("Settlement amount must be positive.")

        surcharge = amount * 0.025
        total_deduction = amount + surcharge

        if total_deduction > self.__credit_limit:
            raise OutOfBoundsError(
                f"CreditAccount [{self.account_id}]: Settlement {amount:.2f} + 2.5% surcharge ({surcharge:.2f}) = "
                f"{total_deduction:.2f}, exceeding available credit limit {self.__credit_limit:.2f}."
            )

        self.__credit_limit = self.__credit_limit - total_deduction
        # Reflect utilized balance on account
        self.balance = self.balance + amount


# Mentor Note: Polymorphic dispatch decouples batch orchestration from concrete subclass types;
# isolated try-except blocks prevent isolated record faults from aborting batch settlement pipelines.
def run_batch(accounts: list, amount: float) -> dict:
    """
    Executes polymorphic batch settlements across heterogeneous account collections.
    
    Each settlement invocation is isolated within its own try-except block,
    ensuring failures on individual accounts never block settlement of remaining peers.
    
    Parameters:
        accounts (list of Account): Heterogeneous list of Account subclasses.
        amount (float): Settlement deduction applied to each account.
        
    Returns:
        dict: Detailed log containing 'successful' and 'failed' settlement lists.
    """
    results = {
        "successful": [],
        "failed": []
    }

    print(f"\n>>> INITIATING POLYMORPHIC BATCH SETTLEMENT [Amount: {amount:.2f}] <<<")

    for acc in accounts:
        try:
            acc.process_settlement(amount)
        except (BaseSystemError, ValueError, TypeError) as exc:
            results["failed"].append({
                "account_id": acc.account_id,
                "account_type": acc.__class__.__name__,
                "error_type": exc.__class__.__name__,
                "reason": str(exc)
            })
            print(f"  [-] SETTLEMENT FAILED  -> Account: {acc.account_id} ({acc.__class__.__name__}) | Error: {exc}")
        else:
            results["successful"].append({
                "account_id": acc.account_id,
                "account_type": acc.__class__.__name__,
                "remaining_balance": acc.balance
            })
            print(f"  [+] SETTLEMENT SUCCESS -> Account: {acc.account_id} ({acc.__class__.__name__}) | Balance: {acc.balance:.2f}")

    # Summary report
    print("\n=== BATCH SETTLEMENT SUMMARY ===")
    print(f"Total Accounts Processed : {len(accounts)}")
    print(f"Total Successful         : {len(results['successful'])}")
    print(f"Total Failed             : {len(results['failed'])}")
    print("================================\n")

    return results


# ============================================================================
# [DEMONSTRATION BLOCK]
# ============================================================================

if __name__ == "__main__":
    print("============================================================================")
    print("   PTMAE: TRANSACTIONAL MICRO-BANKING & AUDIT ENGINE COMPREHENSIVE DEMO     ")
    print("============================================================================")

    # ------------------------------------------------------------------------
    # DEMO 1: Section A — CLI Nested Loops & Crash-Proof Command Execution
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 1] SECTION A: NESTED WHILE LOOPS CLI INTERACTION ---")
    simulated_cli_script = [
        "help",
        "status",
        "calc 10000 0.08 4 2 15 0.001",
        "guard 5000 1000 -1500,-2000,-1000",
        "invalid_random_cmd --test",
        "exit"
    ]
    run_interactive_engine(command_stream=simulated_cli_script)

    # ------------------------------------------------------------------------
    # DEMO 2: Section A — Compound Interest & Penalty Calculator (Pure Arithmetic)
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 2] SECTION A: PURE ARITHMETIC INTEREST & PENALTY ---")
    calc_res = calculate_compound_interest_and_penalty(
        principal=25000.0,
        annual_rate=0.075,
        periods_per_year=12,
        years=3,
        late_penalty_days=10,
        daily_penalty_rate=0.0005
    )
    print(f"Principal          : {calc_res['principal']:.2f}")
    print(f"Compounded Balance : {calc_res['compounded_balance']:.2f}")
    print(f"Penalty Accrued    : {calc_res['penalty_charge']:.2f}")
    print(f"Total Due          : {calc_res['total_due']:.2f}")

    # ------------------------------------------------------------------------
    # DEMO 3: Section A — Trajectory Guard Short-Circuit Evaluation
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 3] SECTION A: TRAJECTORY GUARD SHORT-CIRCUITING ---")
    event_stream = [
        {"amount": 5000.0, "flag": None, "tx_id": "INIT"},
        {"amount": -1200.0, "flag": None, "tx_id": "TX_1"},
        {"amount": -1500.0, "flag": None, "tx_id": "TX_2"},
        {"amount": -1800.0, "flag": None, "tx_id": "TX_3"},  # Breaches 1000 threshold
        {"amount": -500.0, "flag": None, "tx_id": "TX_4"}
    ]
    guard_res = guard_trajectory(event_stream, safety_threshold=1000.0)
    print(f"Guard Stopped Early : {guard_res['halted_early']}")
    print(f"Halt Reason         : {guard_res['halt_reason']}")
    print(f"Final Balance       : {guard_res['final_balance']:.2f}")
    print(f"Steps Completed     : {guard_res['processed_steps']} of {guard_res['total_events']}")

    # ------------------------------------------------------------------------
    # DEMO 4: Section B — Hand-Written Parser (No split/replace, edge cases)
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 4] SECTION B: MANUAL LOG PARSER EDGE CASES ---")
    parser_test_cases = [
        ('Acc101,SAVINGS,5200.00', "Standard valid CSV record"),
        ('Acc102,"CURRENT,ENTERPRISE",8400.50', "Delimiter nested inside quotes"),
        ('Acc103,"Note with ""Escaped"" Quotes",1200.00', "Escaped quotes inside quoted token"),
        ('Acc104,,3500.00', "Empty field preservation"),
        ('Acc105,CREDIT,10000.00,', "Trailing delimiter tolerance")
    ]
    for raw_test, description in parser_test_cases:
        parsed_tokens = parse_raw_log_line(raw_test)
        print(f"Input : {raw_test}")
        print(f"  -> Tokens ({description}): {parsed_tokens}")

    # ------------------------------------------------------------------------
    # DEMO 5: Section B — Audit Filter with Persistent Nonlocal State
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 5] SECTION B: AUDIT FILTER NONLOCAL COUNTERS ---")
    filter_a = make_audit_filter(threshold=5000.0)
    filter_b = make_audit_filter(threshold=10000.0)

    print("Filter A (5000 Threshold) Call 1:", filter_a(3000.0, "Normal salary"))
    print("Filter A (5000 Threshold) Call 2:", filter_a(7500.0, "Large equipment purchase"))
    print("Filter A (5000 Threshold) Call 3:", filter_a(12000.0, "Real estate advance"))
    print("Filter B (10000 Threshold) Call 1 (Independent):", filter_b(8000.0, "Wholesale batch"))
    print("Filter B (10000 Threshold) Call 2 (Independent):", filter_b(15000.0, "Bulk vendor settlement"))

    # ------------------------------------------------------------------------
    # DEMO 6: Section B — Parameterized Position Filters (k=k Late Binding Fix)
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 6] SECTION B: POSITION-BASED FILTERS WITH DEFAULT ARGS ---")
    k_filters = build_position_filters(4)
    sample_record = ["REC990", "SAVINGS", "", "VERIFIED"]
    for idx, f_k in enumerate(k_filters):
        print(f"Filter at position {idx} valid: {f_k(sample_record)}")

    # ------------------------------------------------------------------------
    # DEMO 7: Section C — Reverse Service Index Single Dict Comprehension
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 7] SECTION C: SINGLE DICT COMPREHENSION REVERSE INDEX ---")
    raw_bank_db = {
        "BRANCH_01": [("Acc1@1", {"DEPOSIT", "UPI"}), ("Acc1@2", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    rev_index = build_reverse_service_index(raw_bank_db)
    for service, entries in rev_index.items():
        print(f"Service '{service}': {entries}")

    # ------------------------------------------------------------------------
    # DEMO 8: Section C — scrub_queue Same-Object Mutation & id() Check
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 8] SECTION C: SAME-OBJECT SCRUB_QUEUE & ID PRESERVATION ---")
    test_queue = [
        ("TupleItem1", 100),
        {101, 102, 103, 104, 105},   # Set with even (102, 104) and odd (101, 103, 105) ints
        [4, 1, 9, 2, 7],             # Inner list to sort descending
        "DUPLICATE_PRIMITIVE",
        42,
        "DUPLICATE_PRIMITIVE",
        42,
        True,
        "UNIQUE_PRIMITIVE",
        True
    ]
    id_before = id(test_queue)
    print(f"Queue ID Before : {id_before}")
    print(f"Content Before  : {test_queue}")

    scrub_queue(test_queue)

    id_after = id(test_queue)
    print(f"Queue ID After  : {id_after}")
    print(f"Content After   : {test_queue}")
    print(f"Verified Same Object (id_before == id_after): {id_before == id_after}")

    # ------------------------------------------------------------------------
    # DEMO 9: Section D — r+ File Surgery (In-Place Overwrite, Contraction, Expansion)
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 9] SECTION D: R+ CHUNKED FILE SURGERY ---")
    db_filename = "accounts.db"
    ledger_filename = "ledger.txt"
    corrupted_filename = "corrupted.log"

    # Setup initial accounts.db seed records
    initial_seed = (
        "Acc101,SAVINGS,5200.00\n"
        "Acc102,CURRENT,3400.00\n"
        "Acc103,CREDIT,12000.00\n"
        "Acc104,SAVINGS,9800.00\n"
    )
    with open(db_filename, "w", encoding="utf-8", newline="") as f_seed:
        f_seed.write(initial_seed)

    print("Initial accounts.db contents:")
    with open(db_filename, "r", encoding="utf-8", newline="") as f_read:
        print(f_read.read(), end="")

    # Sub-test A: Exact Length Overwrite
    print("\n> Testing Exact-Length Overwrite on Acc102...")
    update_account_record_inplace(db_filename, "Acc102", "CURRENT", 3400.00)

    # Sub-test B: Contraction (Shorter payload)
    print("> Testing Contraction Surgery on Acc101 (5200.00 -> 10.00)...")
    update_account_record_inplace(db_filename, "Acc101", "SAVINGS", 10.00)

    # Sub-test C: Expansion (Longer payload)
    print("> Testing Expansion Surgery on Acc103 (12000.00 -> 987654321.50)...")
    update_account_record_inplace(db_filename, "Acc103", "CREDIT", 987654321.50)

    print("\nResultant accounts.db contents after surgical passes:")
    with open(db_filename, "r", encoding="utf-8", newline="") as f_read:
        print(f_read.read(), end="")

    # ------------------------------------------------------------------------
    # DEMO 10: Section D — Dual Audit Logging (try-except-else-finally)
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 10] SECTION D: DUAL AUDIT LOGGING WITH TRY-EXCEPT-ELSE-FINALLY ---")
    audit_batch = [
        ("Acc104", "SAVINGS", 4500.00),         # Valid update
        ("Acc999", "SAVINGS", 1000.00),         # Rejection: Non-existent account
        ("Acc101", "INVESTMENT", 5000.00),      # Rejection: Unknown account type
        ("Acc103", "CREDIT", "NON_NUMERIC_BAL") # Rejection: Non-numeric balance
    ]
    audit_and_execute_file_batch(db_filename, ledger_filename, corrupted_filename, audit_batch)

    print("\nContents of ledger.txt (Accepted Updates):")
    with open(ledger_filename, "r", encoding="utf-8") as f_l:
        print(f_l.read(), end="")

    print("\nContents of corrupted.log (Rejected Records with Line Numbers):")
    with open(corrupted_filename, "r", encoding="utf-8") as f_c:
        print(f_c.read(), end="")

    # ------------------------------------------------------------------------
    # DEMO 11: Section E — Accounts Encapsulation & Name Mangling Proof
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 11] SECTION E: NAME MANGLING & ENCAPSULATION DEMO ---")
    base_acc = Account("ACC_BASE_001", 5000.0)
    print(f"Created base account: ID={base_acc.account_id}, Balance={base_acc.balance:.2f}")
    print(f"Total Accounts Created (Class Attribute): {Account.total_accounts}")

    # Demonstrate unmangled access fails with AttributeError
    try:
        unmangled_val = base_acc.__balance
        print(f"[UNEXPECTED] Direct private access succeeded: {unmangled_val}")
    except AttributeError as ae:
        print(f"[EXPECTED FAILURE] Direct access base_acc.__balance raised: {ae}")

    # Demonstrate mangled name works
    mangled_val = getattr(base_acc, "_Account__balance")
    print(f"[MANGLED SUCCESS] Mangled access base_acc._Account__balance: {mangled_val:.2f}")

    # ------------------------------------------------------------------------
    # DEMO 12: Section E — Account Subclasses & Polymorphic Batch Settlement
    # ------------------------------------------------------------------------
    print("\n--- [DEMO 12] SECTION E: ACCOUNT SUBCLASSES & SAFE BATCH SETTLEMENT ---")
    portfolio = [
        SavingsAccount("SAV_1001", initial_balance=5000.0),    # Will succeed (5000 - 1500 = 3500 >= 1000)
        SavingsAccount("SAV_1002", initial_balance=2000.0),    # Will FAIL (2000 - 1500 = 500 < 1000 floor)
        CurrentAccount("CUR_2001", initial_balance=500.0, overdraft_limit=2000.0),  # Will succeed (500 - 1500 = -1000 >= -2000)
        CreditAccount("CRD_3001", credit_limit=5000.0, balance=0.0)  # Will succeed (1500 + 2.5% = 1537.50 <= 5000)
    ]

    settlement_results = run_batch(accounts=portfolio, amount=1500.0)

    print("============================================================================")
    print("   PTMAE ENGINE RUN COMPLETE: ALL TESTS EXECUTED WITH FULL COMPLIANCE       ")
    print("============================================================================")
